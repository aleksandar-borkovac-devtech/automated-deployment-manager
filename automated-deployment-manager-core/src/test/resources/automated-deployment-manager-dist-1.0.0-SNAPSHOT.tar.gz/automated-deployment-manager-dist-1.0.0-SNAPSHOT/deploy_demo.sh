#!/bin/bash
echo "salomo"
cp test.sh salomo.sh
rm salomo.sh
cp /Users/snkpetrus/Development/TQ/automated-deployment-manager/pom.xml /Users/snkpetrus/salomo.xml